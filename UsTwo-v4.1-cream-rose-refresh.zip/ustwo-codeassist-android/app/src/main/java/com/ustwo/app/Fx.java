package com.ustwo.app;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** Small animation helpers used across the whole app. */
final class Fx {
    private Fx() { }

    /** Fade + slide up + soft scale in. */
    static void enter(View v, long delay, float dy) {
        v.setAlpha(0f); v.setTranslationY(dy); v.setScaleX(0.97f); v.setScaleY(0.97f);
        v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(delay).setDuration(460).setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    /** Animate every child of a group in, one after another. */
    static void stagger(ViewGroup g, float dy) {
        int n = g.getChildCount();
        for (int i = 0; i < n; i++) enter(g.getChildAt(i), Math.min(i, 10) * 70L, dy);
    }

    /** Slide + fade a whole screen in. */
    static void swapIn(View v, float dx) {
        v.setAlpha(0f); v.setTranslationX(dx);
        v.animate().alpha(1f).translationX(0f).setDuration(320).setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    /** Springy press feedback. Does not consume the touch. */
    static void press(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(new OvershootInterpolator(3.5f)).start();
            }
            return false;
        });
    }

    /** Quick bouncy pop (likes, mode switches). */
    static void pop(View v) {
        v.animate().cancel();
        v.setScaleX(0.6f); v.setScaleY(0.6f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(new OvershootInterpolator(4f)).start();
    }

    /** Run an animator forever and stop it when the view leaves the screen. */
    static ObjectAnimator loop(View v, final ObjectAnimator a) {
        a.setRepeatCount(ValueAnimator.INFINITE);
        a.setRepeatMode(ValueAnimator.REVERSE);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        v.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View x) { }
            @Override public void onViewDetachedFromWindow(View x) { a.cancel(); }
        });
        a.start();
        return a;
    }

    static ObjectAnimator heartbeat(View v) {
        return loop(v, ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.14f)).setDuration(650));
    }

    static ObjectAnimator shimmer(View v) {
        return loop(v, ObjectAnimator.ofFloat(v, View.ALPHA, 0.45f, 1f).setDuration(800));
    }

    static ObjectAnimator bob(View v, float dy) {
        return loop(v, ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, -dy, dy).setDuration(2200));
    }
}
